<?php

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Deviation;
use Validator;
use Auth;
use DB;
use Exception
class DeviationController extends Controller
{
    public function __construct()
    {

        $this->middleware('permission:deviation-browse',['except' => ['show']]);
        $this->middleware('permission:deviation-add', ['only' => ['store']]);
        $this->middleware('permission:deviation-edit', ['only' => ['update']]);
        $this->middleware('permission:deviation-read', ['only' => ['show']]);
        $this->middleware('permission:deviation-delete', ['only' => ['destroy']]);
        
    }
	public function deviations(Request $request)
    {
        try {
	        $user = getUser();
            $branch_id = (!empty($user->branch_id)) ?$user->branch_id : $user->id;
            $branchids = branchChilds($branch_id);
            $allChilds = array_merge($branchids,[$branch_id]);
            $query = Deviation::with('Parent:id,title','Activity:id,title','Category:id,name','Subcategory:id,name','EditedBy:id,name','ApprovedBy:id,name','Patient:id,name','Employee:id,name');
            if($user->user_type_id =='2'){
                
                $query = $query->orderBy('id','DESC');
            } else{
                $query =  $query->whereIn('branch_id',$allChilds);
            }
	        $whereRaw = $this->getWhereRawFromRequest($request);
            if($whereRaw != '') { 
                $query =   $query->whereRaw($whereRaw)
                ->orderBy('id', 'DESC');
                
            } else {
                $query =  $query->orderBy('id', 'DESC');
            }
            if(!empty($request->perPage))
            {
                $perPage = $request->perPage;
                $page = $request->input('page', 1);
                $total = $query->count();
                $result = $query->offset(($page - 1) * $perPage)->limit($perPage)->get();

                $pagination =  [
                    'data' => $result,
                    'total' => $total,
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'last_page' => ceil($total / $perPage)
                ];
                return prepareResult(true,"Deviation list",$pagination,config('httpcodes.success'));
            }
            else
            {
                $query = $query->get();
            }
            
            return prepareResult(true,"Deviation list",$query,config('httpcodes.success'));
	    }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    	
    }

    public function store(Request $request){
        DB::beginTransaction();
        try {
	    	$user = getUser();
	    	$validator = Validator::make($request->all(),[  
        		'category_id' => 'required|exists:category_masters,id',   
        		'title' => 'required',   
        		'description' => 'required',       
	        ],
            [  
                'category_id' =>  getLangByLabelGroups('Deviation','category_id'),   
                'title' =>  getLangByLabelGroups('Deviation','title'),   
                'description' =>  getLangByLabelGroups('Deviation','description'),     
            ]);
	        if ($validator->fails()) {
            	return prepareResult(false,$validator->errors()->first(),[], config('httpcodes.bad_request')); 
        	}
        	
        	
	        $Deviation = new Deviation;
		 	$Deviation->activity_id = $request->activity_id;
            $Deviation->branch_id = getBranchId();
		 	$Deviation->journal_id = $request->journal_id;
		 	$Deviation->ip_id = $request->ip_id;
		 	$Deviation->patient_id = $request->patient_id;
		 	$Deviation->emp_id = $request->emp_id;
		 	$Deviation->category_id = $request->category_id;
		 	$Deviation->subcategory_id = $request->subcategory_id;
		 	$Deviation->title = $request->title;
		 	$Deviation->description = $request->description;
		 	$Deviation->is_deviation = ($request->is_deviation)? $request->is_deviation :0;
		 	$Deviation->not_a_deviation = ($request->not_a_deviation)? $request->not_a_deviation :0;
		 	$Deviation->reason_of_not_being_deviation = ($request->reason_of_not_being_deviation)? $request->reason_of_not_being_deviation :null;
            $Deviation->entry_mode = (!empty($request->entry_mode)) ? $request->entry_mode :'Web';
		 	$Deviation->save();
             DB::commit();
	        return prepareResult(true,getLangByLabelGroups('Deviation','create') ,$Deviation, config('httpcodes.success'));
        }
        catch(Exception $exception) {
             \Log::error($exception);
            DB::rollback();
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }

    public function update(Request $request,$id){
        DB::beginTransaction();
        try {
	    	$user = getUser();
	    	$validator = Validator::make($request->all(),[    
                'category_id' => 'required|exists:category_masters,id',   
        		'title' => 'required',   
        		'description' => 'required',      
	        ],
            [   
                'category_id' =>  getLangByLabelGroups('Deviation','category_id'),   
                'title' =>  getLangByLabelGroups('Deviation','title'),   
                'description' =>  getLangByLabelGroups('Deviation','description'),     
            ]);
	        if ($validator->fails()) {
            	return prepareResult(false,$validator->errors()->first(),[], config('httpcodes.bad_request')); 
        	}
        	$checkId = Deviation::where('id',$id)
                ->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('Deviation','id_not_found'), [],config('httpcodes.not_found'));
            }
            
        	$parent_id  = (is_null($checkId->parent_id)) ? $id : $checkId->parent_id;
        	$Deviation = new Deviation;
	       	$Deviation->parent_id = $parent_id;
		 	$Deviation->activity_id = $request->activity_id;
            $Deviation->branch_id = getBranchId();
		 	$Deviation->journal_id = $request->journal_id;
		 	$Deviation->ip_id = $request->ip_id;
		 	$Deviation->patient_id = $request->patient_id;
		 	$Deviation->emp_id = $request->emp_id;
		 	$Deviation->category_id = $request->category_id;
		 	$Deviation->subcategory_id = $request->subcategory_id;
		 	$Deviation->title = $request->title;
		 	$Deviation->description = $request->description;
		 	$Deviation->is_deviation = ($request->is_deviation)? $request->is_deviation :0;
		 	$Deviation->not_a_deviation = ($request->not_a_deviation)? $request->not_a_deviation :0;
		 	$Deviation->reason_of_not_being_deviation = ($request->reason_of_not_being_deviation)? $request->reason_of_not_being_deviation :null;
		 	$Deviation->edited_by = $user->id;
		 	$Deviation->reason_for_editing = $request->reason_for_editing;
            $Deviation->entry_mode = (!empty($request->entry_mode)) ? $request->entry_mode :'Web';
		 	$Deviation->save();
		  DB::commit();
	        return prepareResult(true,getLangByLabelGroups('Deviation','update') ,$Deviation, config('httpcodes.success'));
			  
        }
        catch(Exception $exception) {
             \Log::error($exception);
            DB::rollback();
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }
    public function destroy($id){
    	
        try {
	    	$user = getUser();
        	$checkId= Deviation::where('id',$id)->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('Deviation','id_not_found'), [],config('httpcodes.not_found'));
            }
        	$Deviation = Deviation::where('id',$id)->delete();
         	return prepareResult(true,getLangByLabelGroups('Deviation','delete') ,[], config('httpcodes.success'));
		     	
			    
        }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),$exception->getMessage(), config('httpcodes.internal_server_error'));
            
        }
    }
    public function approvedDeviation(Request $request){
        try {
	    	$user = getUser();
	    	$validator = Validator::make($request->all(),[
        		'id' => 'required',   
	        ],
            [
                'id' =>  getLangByLabelGroups('Journal','id'),   
            ]);
	        if ($validator->fails()) {
            	return prepareResult(false,$validator->errors()->first(),[], config('httpcodes.bad_request')); 
        	}
        	$id = $request->id;
        	$checkId= Deviation::where('id',$id)
                ->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('Deviation','id_not_found'), [],config('httpcodes.not_found'));
            }
            $Deviation = Deviation::find($id);
		 	$Deviation->approved_by = $user->id;
		 	$Deviation->approved_date = date('Y-m-d');
		 	$Deviation->status = '1';
		 	$Deviation->save();
	        return prepareResult(true,getLangByLabelGroups('Deviation','approve') ,$Deviation, config('httpcodes.success'));
        }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }
    public function show($id){
        try {
	    	$user = getUser();
        	$checkId= Deviation::where('id',$id)
                ->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('Deviation','id_not_found'), [],config('httpcodes.not_found'));
            }

        	$Deviation = Deviation::where('id',$id)->with('Parent:id,title','Activity:id,title','Category:id,name','Subcategory:id,name','EditedBy:id,name','ApprovedBy:id,name','Patient:id,name','Employee:id,name','children')->first();
	        return prepareResult(true,'View Patient plan' ,$Deviation, config('httpcodes.success'));
        }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }
    private function getWhereRawFromRequest(Request $request) {
        $w = '';
        if (is_null($request->input('status')) == false) {
            if ($w != '') {$w = $w . " AND ";}
            $w = $w . "(" . "status = "."'" .$request->input('status')."'".")";
        }
        if (is_null($request->input('branch_id')) == false) {
            if ($w != '') {$w = $w . " AND ";}
            $w = $w . "(" . "branch_id = "."'" .$request->input('branch_id')."'".")";
        }
        return($w);

    }
    
}
