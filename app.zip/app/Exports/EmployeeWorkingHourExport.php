<?php

namespace App\Exports;

use App\Models\Schedule;
use App\Models\Language;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\Exportable;
use Auth;

class EmployeeWorkingHourExport implements FromCollection, WithHeadings
{
	use Exportable;

    public $data;

    public function __construct($data)
    {
        $this->data = $data;
    }
    public function headings(): array {
    	return  [
            'Employee Name',
            'Scheduled Hour',
            'Extra Hour',
            'Emergency Hour',
            'vacation Hour',
            'Total Hour'
        ];
    }

    public function collection()
    {
        $schedules  = Schedule::wherebetween('shift_date',$data)->groupBy('user_id')->get(['user_id']);
        $language_id = Language::first()->id;
    	$labels = Label::where('language_id',$language_id)->orderBy('group_id', 'ASC')->get();
    	return $labels->map(function ($data, $key) {
            $file_value = [
                'SNO' => $key+1,
                'group_name' => ($data->group) ? $data->group->name : null,
                'label_name' => $data->label_name
            ];
            $languages = Language::all();
            foreach ($languages as $key => $value) {
                $label_value = Label::where('language_id',$value->id)->where('label_name',$data->label_name)->first();
                $file_value[] = $label_value ? $label_value->label_value : '';
            }
            $file_value[] = '';
            return $file_value;
    	});
    }
}
