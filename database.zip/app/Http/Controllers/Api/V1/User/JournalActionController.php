<?php

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JournalAction;
use Validator;
use Auth;
use DB;
use App\Models\JournalActionLog;
use Exception;
class JournalActionController extends Controller
{
    public function __construct()
    {

        $this->middleware('permission:journal-action-browse',['except' => ['show']]);
        $this->middleware('permission:journal-action-add', ['only' => ['store']]);
        $this->middleware('permission:journal-action-edit', ['only' => ['update']]);
        $this->middleware('permission:journal-action-read', ['only' => ['show']]);
        $this->middleware('permission:journal-action-delete', ['only' => ['destroy']]);
        
    }
	public function journalActions(Request $request)
    {
      
        try {
	        $user = getUser();
	        $branch_id = (!empty($user->branch_id)) ?$user->branch_id : $user->id;
            $branchids = branchChilds($branch_id);
            $allChilds = array_merge($branchids,[$branch_id]);
            $query = Journal::with('Parent:id','Activity:id,title','Category:id,name','Subcategory:id,name','EditedBy:id,name','ApprovedBy:id,name','Patient:id,name','Employee:id,name');
            

            if($user->user_type_id =='2'){
                
                $query = $query->orderBy('id','DESC');
            } else{
                $query =  $query->whereIn('id',$allChilds);
            }
            $whereRaw = $this->getWhereRawFromRequest($request);

            return $whereRaw;
            if($whereRaw != '') { 
                $query =  $query->whereRaw($whereRaw)
                 ->orderBy('id', 'DESC');
                
               
            } else {
                $query = $query->orderBy('id', 'DESC');
                
            }

            // if(!empty($request->type)){
            //     $query = $query->orderBy('id','DESC');
            // }

            if(!empty($request->perPage))
            {
                $perPage = $request->perPage;
                $page = $request->input('page', 1);
                $total = $query->count();
                $result = $query->offset(($page - 1) * $perPage)->limit($perPage)->get();

                $pagination =  [
                    'data' => $result,
                    'total' => $total,
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'last_page' => ceil($total / $perPage)
                ];
                return prepareResult(true,"Journal list",$pagination,config('httpcodes.success'));
            }
            else
            {
                $query = $query->get();
            }
            
            return prepareResult(true,"Journal list",$query,config('httpcodes.success'));
	    
	    }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    	
    }

    public function store(Request $request){
        DB::beginTransaction();
        try {
	    	$user = getUser();
	    	$validator = Validator::make($request->all(),[
        		'journal_id' => 'required|exists:journals,id',    
        		'result' => 'required',   
        		'description' => 'required',       
	        ],
            [
                'journal_id' =>  getLangByLabelGroups('Journal','journal_id'),   
                'result' =>  getLangByLabelGroups('Journal','result'),   
                'description' =>  getLangByLabelGroups('Journal','description'), 
            ]);
	        if ($validator->fails()) {
            	return prepareResult(false,$validator->errors()->first(),[], config('httpcodes.bad_request')); 
        	}
        	
	        $journalAction = new JournalAction;
		 	$journalAction->journal_id = $request->journal_id;
		 	$journalAction->description = $request->description;
            $journalAction->result = $request->result;
            $journalAction->is_signed = ($request->is_signed)? $request->is_signed :0;
		 	$journalAction->save();
             DB::commit();
	        return prepareResult(true,getLangByLabelGroups('JournalAction','create') ,$journalAction, config('httpcodes.success'));
        }
        catch(Exception $exception) {
             \Log::error($exception);
            DB::rollback();
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }

    public function update(Request $request,$id){
        DB::beginTransaction();
        try {
	    	$user = getUser();

	    	$validator = Validator::make($request->all(),[
                'journal_id' => 'required|exists:journals,id',    
                'result' => 'required',   
                'description' => 'required',       
            ],
            [
                'journal_id' =>  getLangByLabelGroups('Journal','journal_id'),   
                'result' =>  getLangByLabelGroups('Journal','result'),   
                'description' =>  getLangByLabelGroups('Journal','description'), 
            ]);
	        if ($validator->fails()) {
            	return prepareResult(false,$validator->errors()->first(),[], config('httpcodes.bad_request')); 
        	}
        	
        	$checkId = JournalAction::where('id',$id)
                ->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('JournalAction','id_not_found'), [],config('httpcodes.not_found'));
            }



            if($checkId->is_signed == 1){
                $journalActionLog                     = new JournalActionLog;
                $journalActionLog->journal_id         = $checkId->journal_id;
                $journalActionLog->parent_id          = $checkId->parent_id;
                $journalActionLog->activity_id        = $checkId->activity_id;
                $journalActionLog->branch_id          = $checkId->branch_id;
                $journalActionLog->deviation_id       = $checkId->deviation_id;
                $journalActionLog->patient_id         = $checkId->patient_id;
                $journalActionLog->emp_id             = $checkId->emp_id;
                $journalActionLog->category_id        = $checkId->category_id;
                $journalActionLog->subcategory_id     = $checkId->subcategory_id;
                $journalActionLog->description        = $checkId->description;
                $journalActionLog->edited_by          = $request->edited_by;
                $journalActionLog->reason_for_editing = $request->reason_for_editing;
                $journalActionLog->date                  = $checkId->date;
                $journalActionLog->time                  = $checkId->time;
                $journalActionLog->type                  = $checkId->type;
                $journalActionLog->save();
            }



        	$parent_id  = (is_null($checkId->parent_id)) ? $id : $checkId->parent_id;
        	$journalAction = Journal::where('id',$id)->first();
	       	$journalAction->activity_id = $request->activity_id;
            $journalAction->description = $request->description;
            $journalAction->is_signed = ($request->is_signed)? $request->is_signed :0;
            $journalAction->result = $request->result;
		 	$journalAction->edited_by = $user->id;
		 	$journalAction->reason_for_editing = $request->reason_for_editing;
		 	$journalAction->save();
		       DB::commit();
	        return prepareResult(true,getLangByLabelGroups('Journal','update') ,$journalAction, config('httpcodes.success'));
			  
        }
        catch(Exception $exception) {
             \Log::error($exception);
            DB::rollback();
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }
    public function destroy($id){
  
        try {
	    	$user = getUser();
        	$checkId= Journal::where('id',$id)->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('Journal','id_not_found'), [],config('httpcodes.not_found'));
            }
        	$journal = Journal::where('id',$id)->delete();
         	return prepareResult(true,getLangByLabelGroups('Journal','delete') ,[], config('httpcodes.success'));
		     	
			    
        }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),$exception->getMessage(), config('httpcodes.internal_server_error'));
            
        }
    }
    public function approvedJournal(Request $request){
    
        try {
	    	$user = getUser();
	    	$validator = Validator::make($request->all(),[
        		'id' => 'required',   
	        ],
            [
                'id' =>  getLangByLabelGroups('Journal','id'),   
            ]);
	        if ($validator->fails()) {
            	return prepareResult(false,$validator->errors()->first(),[], config('httpcodes.bad_request')); 
        	}
        	$id = $request->id;
        	$checkId= Journal::where('id',$id)
                ->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('Journal','id_not_found'), [],config('httpcodes.not_found'));
            }
            $journal = Journal::find($id);
		 	$journalAction->approved_by = $user->id;
		 	$journalAction->approved_date = date('Y-m-d');
		 	$journalAction->status = '1';
		 	$journalAction->save();
	        return prepareResult(true,getLangByLabelGroups('Journal','delete'),$journalAction, config('httpcodes.success'));
        }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }
    public function show(Request $request){
        try {
	    	$user = getUser();
        	$checkId= Journal::where('id',$id)
                ->first();
			if (!is_object($checkId)) {
                return prepareResult(false,getLangByLabelGroups('Journal','id_not_found'), [],config('httpcodes.not_found'));
            }

        	$journal = Journal::where('id',$id)->with('Parent:id,title','Activity:id,title','Category:id,name','Subcategory:id,name','EditedBy:id,name','ApprovedBy:id,name','Patient:id,name','Employee:id,name','children')->first();
	        return prepareResult(true,'View Patient plan' ,$journalAction, config('httpcodes.success'));
        }
        catch(Exception $exception) {
            return prepareResult(false, $exception->getMessage(),[], config('httpcodes.internal_server_error'));
            
        }
    }
    private function getWhereRawFromRequest(Request $request) {
        $w = '';
        if (is_null($request->input('status')) == false) {
            if ($w != '') {$w = $w . " AND ";}
            $w = $w . "(" . "status = "."'" .$request->input('status')."'".")";
        }
        if (is_null($request->input('branch_id')) == false) {
            if ($w != '') {$w = $w . " AND ";}
            $w = $w . "(" . "branch_id = "."'" .$request->input('branch_id')."'".")";
        }
        return($w);

    }
    
}
